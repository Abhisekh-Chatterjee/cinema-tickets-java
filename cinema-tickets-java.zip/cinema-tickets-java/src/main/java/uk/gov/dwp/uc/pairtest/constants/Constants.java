package uk.gov.dwp.uc.pairtest.constants;

public class Constants {
	
	public static final int CHILD_FARE = 10;
	
	public static final int ADULT_FARE = 20;
	
	public static final int MAXIMUM_TICKETS = 20;
	
	public static final String INVALID_TICKET_TYPE = "Invalid Ticket Type";
	
	public static final String NO_ADULT_TICKET_REQUESTED = "Invalid Request as no Adult ticket requested!";
	
	public static final String EXCESS_TICKETS_REQUESTED = "Invalid Request as more than 20 tickets have "
															+ "been requested!";
	
	public static final String INVALID_ACCOUNT_ID = "Invalid Account ID";

}
