package uk.gov.dwp.uc.pairtest;

import java.util.Arrays;

import thirdparty.paymentgateway.TicketPaymentService;
import thirdparty.seatbooking.SeatReservationService;
import uk.gov.dwp.uc.pairtest.constants.Constants;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest.Type;
import uk.gov.dwp.uc.pairtest.exception.InvalidPurchaseException;

public class TicketServiceImpl implements TicketService {
    /**
     * Should only have private methods other than the one below.
     */
	
	private TicketPaymentService ticketPaymentService;
	
	private SeatReservationService seatReservationService;
	
	/**
	 * @author DWP
     * @param accountId
     * @param ticketTypeRequests
     * {@summary This method is used to Purchase Tickets}
	 */

    @Override
    public void purchaseTickets(Long accountId, TicketTypeRequest... ticketTypeRequests) throws InvalidPurchaseException {
    	
    	// To calculate total amount to be paid by a purchaser
    	int totalAmountToPay = 0;
    	
    	// To check if an Adult Ticket is requested by a purchaser
    	boolean adultTicketPresent = false;
    	
    	// To calculate total tickets requested by a purchaser
    	int totalTicketsRequested = 0;
    	
    	//To calculate total seats to be reserved for a purchaser
    	int totalSeatsToAllocate = 0;
    	
    	// Check if Account ID is valid
    	if(accountId > 0) {
    		
    		for(TicketTypeRequest req : ticketTypeRequests) {
    			
    			//Check the ticket type belongs to a valid type
    			if(isValidTicketType(req.getTicketType().toString(), Type.class)) {
	    			
    				// Calculation of fare, tickets requested and seats to be reserved for Adults
    				if(req.getTicketType() == Type.ADULT) {
	    				totalAmountToPay += req.getNoOfTickets() * Constants.ADULT_FARE;
	    				
	    				totalTicketsRequested += req.getNoOfTickets();
	    				
	    				totalSeatsToAllocate += req.getNoOfTickets();
	    				
	    				adultTicketPresent = true;
	    			
	    			// Calculation of fare, tickets requested and seats to be reserved for Children
    				} else if (req.getTicketType() == Type.CHILD) {
	    				
    					totalAmountToPay += req.getNoOfTickets() * Constants.CHILD_FARE;
	    				
    					totalTicketsRequested += req.getNoOfTickets();
	    				
    					totalSeatsToAllocate += req.getNoOfTickets();
	    				
	    			// Calculation tickets requested for Infants. The Fare and seats not counted for this category.	
	    			} else {
	    				totalTicketsRequested += req.getNoOfTickets();
	    			}
    			} else {
    				throw new InvalidPurchaseException(Constants.INVALID_TICKET_TYPE);
    			}
    		}
    		
    		if(!adultTicketPresent) {
    			throw new InvalidPurchaseException(Constants.NO_ADULT_TICKET_REQUESTED);
    		}else if(totalTicketsRequested > Constants.MAXIMUM_TICKETS) {
    			throw new InvalidPurchaseException(Constants.EXCESS_TICKETS_REQUESTED);
    		} else {
    			// call the Payment Service
    			ticketPaymentService.makePayment(accountId, totalAmountToPay);
    			
    			// Once Payment is successful call the Seat Reservation Service
    			seatReservationService.reserveSeat(accountId, totalSeatsToAllocate);
    		}
    		
    	} else {
    		throw new InvalidPurchaseException(Constants.INVALID_ACCOUNT_ID);
    	}

    }
    
    /**
     * @author DWP
     * @param ticketType
     * @param type
     * {@summary This method is used to check if the Ticket Type is valid}
     * @return boolean
     */
    private boolean isValidTicketType(String ticketType, Class<Type> type) {
        return Arrays.stream(type.getEnumConstants()).anyMatch(e -> e.name().equals(ticketType));
      }

}